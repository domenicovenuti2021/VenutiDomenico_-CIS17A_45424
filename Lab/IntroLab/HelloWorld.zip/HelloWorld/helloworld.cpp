/* 
 * File: helloworld.cpp
 * Author: Domenico Venuti
 * Created on June 27, 2021- Assignment_1, 6:16 PM
 * Purpose:  CIS-17A - 45424 - IntroLab (HelloWorld Program)
 */

#include<iostream>

using namespace std;

int main()
{
    cout<<"HelloWord";
    return 0;
}

